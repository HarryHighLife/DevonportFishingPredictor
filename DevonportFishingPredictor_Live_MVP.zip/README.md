# Devonport Fishing Predictor - Live MVP

This is the second prototype of the Android app.

## What is live
- Hourly air temperature and apparent temperature
- Sea-level pressure
- Wind and gusts
- Cloud cover
- Precipitation
- Wave height and wave period
- Modelled sea-surface temperature
- Three Devonport fishing locations/species combinations
- A first-pass 0-100 fishing-condition score

## Data
The prototype uses Open-Meteo's forecast and marine APIs. Their marine service provides wave, SST, sea-level and current variables, but notes that coastal tidal/current accuracy is limited. BOM is the official Australian source to check marine forecasts, warnings and tide predictions.

## Next build
1. Proper BOM tide integration
2. Sunrise/sunset and moon/solunar calculations
3. Species-specific tide weighting
4. Separate safety score for The Bluff
5. Catch log stored on the phone
6. Historical catch calibration
7. Satellite water colour/chlorophyll where a suitable data source is available
8. Phone-friendly release build / APK workflow
