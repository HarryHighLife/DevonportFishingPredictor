package com.devonportfishing.predictor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.max
import kotlin.math.min

data class Spot(val name: String, val lat: Double, val lon: Double, val safetyNote: String)
data class Hour(val time: String, val temp: Double, val feels: Double, val pressure: Double, val wind: Double, val gust: Double, val cloud: Int, val rain: Double, val wave: Double, val wavePeriod: Double, val sst: Double)
data class Forecast(val hours: List<Hour>, val fetchedAt: String)

val MERSEY = Spot("Mersey River • Saltwater", -41.16738, 146.36763, "River-mouth conditions can change quickly with wind, rain and boat traffic.")
val BLUFF = Spot("The Bluff • Rocks", -41.15884, 146.35536, "Rock platforms can become hazardous with swell, surge and changing wave direction. Never use the fishing score as a safety clearance.")

enum class Species(val label: String) { SALMON("Australian Salmon"), FLATHEAD("Flathead"), GUMMY("Gummy Shark") }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FishingApp() }
    }
}

@Composable
fun FishingApp() {
    var spot by remember { mutableStateOf(MERSEY) }
    var species by remember { mutableStateOf(Species.SALMON) }
    var forecast by remember { mutableStateOf<Forecast?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    suspend fun load() {
        loading = true
        error = null
        try {
            forecast = fetchForecast(spot)
        } catch (e: Exception) {
            error = "Couldn't load live conditions. Check your internet connection."
        } finally {
            loading = false
        }
    }

    LaunchedEffect(spot) { load() }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Devonport Fishing Predictor 🎣") }) }
        ) { pad ->
            Column(
                Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Fishing location", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = spot == MERSEY, onClick = { spot = MERSEY }, label = { Text("Mersey") })
                    FilterChip(selected = spot == BLUFF, onClick = { spot = BLUFF }, label = { Text("The Bluff") })
                }

                Text("Target species", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    Species.values().forEach { s ->
                        FilterChip(selected = species == s, onClick = { species = s }, label = { Text(s.label) })
                    }
                }

                Button(onClick = { kotlinx.coroutines.GlobalScope.launch(Dispatchers.Main) { load() } }, enabled = !loading) {
                    Text(if (loading) "Updating…" else "Refresh live conditions")
                }

                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

                val data = forecast
                if (data != null && data.hours.isNotEmpty()) {
                    val ranked = data.hours.map { it to score(it, species) }.sortedByDescending { it.second }.take(5)
                    Card {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Best fishing windows", style = MaterialTheme.typography.titleLarge)
                            Text("Live weather + marine model data. Score is an estimate, not a guarantee of fish activity.")
                            ranked.forEachIndexed { i, pair ->
                                val h = pair.first
                                val score = pair.second
                                val t = h.time.substringAfter("T").take(5)
                                Text("${i + 1}. $t  •  $score/100", style = MaterialTheme.typography.titleMedium)
                                Text("${h.temp.round()}°C air  •  ${h.wind.round()} km/h wind  •  ${h.wave.round(1)}m waves  •  ${h.sst.round(1)}°C SST")
                                LinearProgressIndicator(progress = { score / 100f }, modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }

                    val now = data.hours.first()
                    Card {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Current / next forecast point", style = MaterialTheme.typography.titleLarge)
                            Text("Air: ${now.temp.round()}°C   Feels: ${now.feels.round()}°C")
                            Text("Pressure: ${now.pressure.round(1)} hPa")
                            Text("Wind: ${now.wind.round()} km/h   Gusts: ${now.gust.round()} km/h")
                            Text("Cloud: ${now.cloud}%   Rain: ${now.rain.round(1)} mm")
                            Text("Waves: ${now.wave.round(1)} m   Period: ${now.wavePeriod.round(1)} s")
                            Text("Sea temperature: ${now.sst.round(1)}°C")
                        }
                    }
                }

                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Safety", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(4.dp))
                        Text(spot.safetyNote)
                        Spacer(Modifier.height(4.dp))
                        Text("Always check official BOM marine forecasts and warnings before fishing. The Bluff score never means conditions are safe.")
                    }
                }

                Text("Data sources: Open-Meteo weather/marine forecast for the prototype. BOM remains the official Australian source for marine forecasts and warnings.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

suspend fun fetchForecast(spot: Spot): Forecast = withContext(Dispatchers.IO) {
    val url = "https://api.open-meteo.com/v1/forecast" +
            "?latitude=${spot.lat}&longitude=${spot.lon}" +
            "&hourly=temperature_2m,apparent_temperature,pressure_msl,wind_speed_10m,wind_gusts_10m,cloud_cover,precipitation" +
            "&timezone=Australia%2FHobart&forecast_days=3"
    val weather = JSONObject(URL(url).readText())

    val marineUrl = "https://marine-api.open-meteo.com/v1/marine" +
            "?latitude=${spot.lat}&longitude=${spot.lon}" +
            "&hourly=wave_height,wave_period,sea_surface_temperature" +
            "&timezone=Australia%2FHobart&forecast_days=3"
    val marine = JSONObject(URL(marineUrl).readText())

    val wh = weather.getJSONObject("hourly")
    val mh = marine.getJSONObject("hourly")
    val times = wh.getJSONArray("time")
    val out = mutableListOf<Hour>()
    for (i in 0 until times.length()) {
        fun d(name: String) = wh.getJSONArray(name).optDouble(i, 0.0)
        fun md(name: String) = mh.getJSONArray(name).optDouble(i, 0.0)
        out += Hour(
            times.getString(i), d("temperature_2m"), d("apparent_temperature"),
            d("pressure_msl"), d("wind_speed_10m"), d("wind_gusts_10m"),
            d("cloud_cover").toInt(), d("precipitation"), md("wave_height"),
            md("wave_period"), md("sea_surface_temperature")
        )
    }
    Forecast(out, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")))
}

fun score(h: Hour, species: Species): Int {
    var s = 50.0
    val ideal = when (species) {
        Species.SALMON -> 15.6..22.3
        Species.FLATHEAD -> 15.0..21.0
        Species.GUMMY -> 12.0..20.0
    }
    s += if (h.sst in ideal) 18 else -8
    s += when {
        h.pressure < 1005 -> 5
        h.pressure < 1020 -> 3
        h.pressure <= 1030 -> 0
        else -> -3
    }
    s += when {
        h.wind in 5.0..20.0 -> 7
        h.wind < 5.0 -> 3
        h.wind <= 28.0 -> -3
        else -> -15
    }
    s += when {
        h.cloud in 30..85 -> 5
        h.cloud < 30 -> 2
        else -> -2
    }
    s += when {
        h.wave <= 1.0 && h.wavePeriod >= 6 -> 7
        h.wave <= 1.5 -> 1
        h.wave <= 2.0 -> -7
        else -> -18
    }
    s += when (h.rain) {
        in 0.0..0.5 -> 2
        in 0.5..2.0 -> 0
        else -> -5
    }
    val hour = h.time.substringAfter("T").take(2).toIntOrNull() ?: 12
    if (hour in 5..8 || hour in 17..20) s += 8
    return min(100, max(0, s.roundToInt()))
}

fun Double.round(decimals: Int = 0): String = "%1.${decimals}f".format(this)
fun Double.roundToInt(): Int = kotlin.math.round(this).toInt()
